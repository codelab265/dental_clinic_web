<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GetDataController extends Controller
{
    public function getPatients(Request $request)
    {
    
    }
}
